package validator;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.springwebapp.models.RegUser;

import service.UserService;

@Component
public class UserValidator implements Validator {
    @Autowired
    private UserService userService;

    @Override
    public boolean supports(Class<?> aClass) {
        return RegUser.class.equals(aClass);
    }

    @Override
    public void validate(Object o, Errors errors) {
        RegUser reguser = (RegUser) o;

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "username", "NotEmpty");
        if (reguser.getUser().length() < 6 || reguser.getUser().length() > 32) {
            errors.rejectValue("username", "Size.userForm.username");
        }
        if (userService.findByUsername(reguser.getUser()) != null) {
            errors.rejectValue("username", "Duplicate.userForm.username");
        }

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "NotEmpty");
        if (reguser.getPassword().length() < 8 || reguser.getPassword().length() > 32) {
            errors.rejectValue("password", "Size.userForm.password");
        }

       // if (!user.getPasswordConfirm().equals(user.getPassword())) {
         //   errors.rejectValue("passwordConfirm", "Diff.userForm.passwordConfirm");
       // }
    }
}

