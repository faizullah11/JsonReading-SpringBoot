package com.springwebapp;

import org.springframework.beans.factory.annotation.Autowired;

import com.springwebapp.models.RegUser;
import com.springwebapp.repos.UserRepository;



public class ApplicationUtil {
	
	
	@Autowired
	UserRepository userRepository;
	
	
	
	public RegUser findUser(Long userId) {
		RegUser user = null;
		user = userRepository.findOne(userId);
		return user;
	}
	
	public void updateUser(RegUser user) {
		userRepository.save(user);
	}
	

}
