/**
 * 
 */
package com.springwebapp.controller;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.GZIPInputStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.http.MediaType;
//import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.springwebapp.models.Tour;
import com.springwebapp.repos.ToursRepository;

/**
 * @author faiz
 *
 */
@CrossOrigin(origins = { "*" }, maxAge = 3000)
@RestController
public class TourController {

	public static final String FILE_URL = "https://s3-eu-west-1.amazonaws.com/pocketguide/_test/store_en.v2.gz";
	public static String[] strArray;

	@Autowired
	ToursRepository toursRepository;

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/tours", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Tour> findTour(@Param("name") String name) {

		List<Tour> tours = new ArrayList<>();
		tours = (List<Tour>) toursRepository.findAll();

		return tours;
	}

	@CrossOrigin(origins = "*")
//	@Secured({"user"})
	@RequestMapping(value = "/tours/refresh", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void refreshTour(@Param("name") String name1) {
		try {
			URL url = new URL(FILE_URL);

			HttpURLConnection httpConn = (HttpURLConnection) url.openConnection();
			int responseCode = httpConn.getResponseCode();
			List<Tour> tours = null;
			if (responseCode == HttpURLConnection.HTTP_OK) {
				InputStream gzipStream = new GZIPInputStream(url.openStream());
				Reader decoder = new InputStreamReader(gzipStream, "UTF-8");
				BufferedReader buffered = new BufferedReader(decoder);
				StringBuilder responseStrBuilder = new StringBuilder();
				String inputStr;
				while ((inputStr = buffered.readLine()) != null) {
					responseStrBuilder.append(inputStr);
				}
				JSONObject jsonObject = new JSONObject(responseStrBuilder.toString());
				JSONArray tourJson = jsonObject.getJSONArray("tours");
				ObjectMapper objectMapper = new ObjectMapper();
				if (name1 != null) {
					for (int i = 0; i < tourJson.length(); i++) {
						JSONObject object = tourJson.getJSONObject(i);
						String tourName = object.getString("name");
						if (tourName.equals(name1)) {
							Tour tour = objectMapper.readValue(object.toString(), Tour.class);
							tours = new ArrayList<>();
							tours.add(tour);
							break;
						}
					}
				} else if (name1 == null) {
					TypeToken<List<Tour>> token = new TypeToken<List<Tour>>() {
					};
					tours = new Gson().fromJson(tourJson.toString(), token.getType());
				}
				if (tours != null)
					for (int i = 0; i < tours.size(); i++) {

						toursRepository.save(tours.get(i));

						// System.out.println(((Tour)tours.get(i)).getName());

					}
			}
		} catch (Exception ex) {
			System.out.print("Error: " + ex.getMessage());
		}
	}

	@RequestMapping("/findToursByName")
	public Tour findToursByName(@Param("name") String name) {
		Tour tour = null;
		tour = toursRepository.findByName(name);
		return tour;
	}

}
