/**
 * 
 */
package com.springwebapp.repos;

import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.ResponseBody;

import com.springwebapp.models.RegUser;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author faiz
 *
 */
@RepositoryRestResource(collectionResourceRel = "reguser", path = "/reguser")
public interface UserRepository extends JpaRepository<RegUser, Long> {

	@RequestMapping(path = "/loginUser", produces = "application/json; charset=UTF-8")
	@ResponseBody
	public RegUser findUserByUserAndPassword(@Param("user") String user, @Param("password") String password);

	@RequestMapping(path = "/findByUserId", produces = "application/json; charset=UTF-8")
	@ResponseBody
	public RegUser findByUserId(@Param("userId") Long userId);

	RegUser findByUser(String user);
}
