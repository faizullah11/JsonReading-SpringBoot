package com.springwebapp.repos;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.springwebapp.models.TourOffers;


/**
 * @author faiz
 *
 */

@RepositoryRestResource(collectionResourceRel = "tours", path = "/tours")
public interface OffersRepository extends CrudRepository<TourOffers, Long> {
	

	@RequestMapping(path = "/findByCity", produces = "application/json; charset=UTF-8")
	@ResponseBody
	public List<TourOffers> findByCity(@Param("City") String City);
	
	@RequestMapping(path = "/findByBundle", produces = "application/json; charset=UTF-8")
	@ResponseBody
	public List<TourOffers> findByBundle(@Param("Bundle") String Bundle);
	
}
