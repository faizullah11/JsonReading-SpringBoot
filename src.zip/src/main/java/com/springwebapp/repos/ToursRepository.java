package com.springwebapp.repos;


//import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.springwebapp.models.Tour;

/**
 * @author faiz
 *
 */

@RepositoryRestResource(collectionResourceRel = "tour", path = "/tour")
public interface ToursRepository extends CrudRepository<Tour, Long> {
	

	@RequestMapping(path = "/findByName", produces = "application/json; charset=UTF-8")
	@ResponseBody
	public Tour findByName(@Param("name") String name);
	
		
}
