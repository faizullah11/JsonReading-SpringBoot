/**
 * 
 */
package com.springwebapp.models;



import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author faiz
 *
 */

@Entity
@Table(name = "tour")
public class Tour {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	private String name;

	private String longDesc;

	private String shortDesc;

	private int cityId;
	private boolean html;
	private double birdsEyeLat;
	private double birdsEyeLon;
	private double birdsEyeZoomLevel;
	private boolean buyForOlUse; 
	private double startPathRef;
	private double startLat;
	private double startLon;
	private String lang;
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the longDesc
	 */
	public String getLongDesc() {
		return longDesc;
	}
	/**
	 * @param longDesc the longDesc to set
	 */
	public void setLongDesc(String longDesc) {
		this.longDesc = longDesc;
	}
	/**
	 * @return the shortDesc
	 */
	public String getShortDesc() {
		return shortDesc;
	}
	/**
	 * @param shortDesc the shortDesc to set
	 */
	public void setShortDesc(String shortDesc) {
		this.shortDesc = shortDesc;
	}
	/**
	 * @return the cityId
	 */
	public int getCityId() {
		return cityId;
	}
	/**
	 * @param cityId the cityId to set
	 */
	public void setCityId(int cityId) {
		this.cityId = cityId;
	}
	/**
	 * @return the html
	 */
	public boolean isHtml() {
		return html;
	}
	/**
	 * @param html the html to set
	 */
	public void setHtml(boolean html) {
		this.html = html;
	}
	/**
	 * @return the birdsEyeLat
	 */
	public double getBirdsEyeLat() {
		return birdsEyeLat;
	}
	/**
	 * @param birdsEyeLat the birdsEyeLat to set
	 */
	public void setBirdsEyeLat(Long birdsEyeLat) {
		this.birdsEyeLat = birdsEyeLat;
	}
	/**
	 * @return the birdsEyeLon
	 */
	public double getBirdsEyeLon() {
		return birdsEyeLon;
	}
	/**
	 * @param birdsEyeLon the birdsEyeLon to set
	 */
	public void setBirdsEyeLon(Long birdsEyeLon) {
		this.birdsEyeLon = birdsEyeLon;
	}
	/**
	 * @return the birdsEyeZoomLevel
	 */
	public double getBirdsEyeZoomLevel() {
		return birdsEyeZoomLevel;
	}
	/**
	 * @param birdsEyeZoomLevel the birdsEyeZoomLevel to set
	 */
	public void setBirdsEyeZoomLevel(Long birdsEyeZoomLevel) {
		this.birdsEyeZoomLevel = birdsEyeZoomLevel;
	}
	/**
	 * @return the buyForOlUse
	 */
	public boolean isBuyForOlUse() {
		return buyForOlUse;
	}
	/**
	 * @param buyForOlUse the buyForOlUse to set
	 */
	public void setBuyForOlUse(boolean buyForOlUse) {
		this.buyForOlUse = buyForOlUse;
	}
	/**
	 * @return the startPathRef
	 */
	public double getStartPathRef() {
		return startPathRef;
	}
	/**
	 * @param startPathRef the startPathRef to set
	 */
	public void setStartPathRef(Long startPathRef) {
		this.startPathRef = startPathRef;
	}
	/**
	 * @return the startLat
	 */
	public double getStartLat() {
		return startLat;
	}
	/**
	 * @param startLat the startLat to set
	 */
	public void setStartLat(Long startLat) {
		this.startLat = startLat;
	}
	/**
	 * @return the startLon
	 */
	public double getStartLon() {
		return startLon;
	}
	/**
	 * @param startLon the startLon to set
	 */
	public void setStartLon(Long startLon) {
		this.startLon = startLon;
	}
	/**
	 * @return the lang
	 */
	public String getLang() {
		return lang;
	}
	/**
	 * @param lang the lang to set
	 */
	public void setLang(String lang) {
		this.lang = lang;
	}
	

}
