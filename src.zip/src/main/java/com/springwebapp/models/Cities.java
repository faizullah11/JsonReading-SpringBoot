/**
 * 
 */
package com.springwebapp.models;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author faiz
 *
 */

@Entity
@Table(name = "cities")

public class Cities{
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)

	private int id;
	private String viatorUrl;
	
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the viatorUrl
	 */
	public String getViatorUrl() {
		return viatorUrl;
	}
	/**
	 * @param viatorUrl the viatorUrl to set
	 */
	public void setViatorUrl(String viatorUrl) {
		this.viatorUrl = viatorUrl;
	}

	
}