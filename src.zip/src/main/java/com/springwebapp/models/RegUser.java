/**
 * 
 */
package com.springwebapp.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author faiz
 *
 */
@Entity
@Table(name = "reguser")
public class RegUser {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long userId;

	private String user;
	private String password;




	/**
	 * @return the userId
	 */

	public Long getUserId() {
		return userId;
	}

	/**
	 * @param userId
	 *            the userId to set
	 */
	public void setUserId(Long userId1) {

		this.userId = userId1;
	}

	/**
	 * @return the user
	 */
	public String getUser() {
		return user;
	}

	/**
	 * @param user
	 *            the user to set
	 */
	public void setUser(String user) {
		this.user = user;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password
	 *            the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}


}
