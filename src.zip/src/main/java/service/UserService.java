package service;



import org.springframework.stereotype.Service;

import com.springwebapp.models.RegUser;




@Service
public interface UserService 
{
	
	public default void save(RegUser reguser) {
      
    }

	public default RegUser findByUsername(String username) {
		return null;
       
    }
	
}