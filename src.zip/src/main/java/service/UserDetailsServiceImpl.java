package service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.transaction.annotation.Transactional;

import com.springwebapp.models.RegUser;
import com.springwebapp.repos.UserRepository;

import java.util.HashSet;

import java.util.Set;


public class UserDetailsServiceImpl implements UserDetailsService{

	   @Autowired
	    private UserRepository userRepository;

	    @Override
	    @Transactional(readOnly = true)
	    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
	        RegUser reguser = userRepository.findByUser(username);

	        Set<GrantedAuthority> grantedAuthorities = new HashSet<>();
	       // for (Role role : user.getRoles()){
	         //   grantedAuthorities.add(new SimpleGrantedAuthority(role.getName()));
	       // }

	        return new org.springframework.security.core.userdetails.User(reguser.getUser(), reguser.getPassword(), grantedAuthorities);
	    }
	}

