package service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.springwebapp.models.RegUser;
import com.springwebapp.repos.UserRepository;


public class UserServiceImpl implements UserService {
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;

	@Override
	public void save(RegUser reguser) {
		reguser.setPassword(bCryptPasswordEncoder.encode(reguser.getPassword()));
		//user.setRoles(new ArrayList<>(roleRepository.findAll()));
		userRepository.save(reguser);
	}

	@Override
	public RegUser findByUsername(String user) {
		return userRepository.findByUser(user);
	}

}
